# Cloudflare Worker Setup — Free Anonymous Analytics

This replaces Google Analytics with a zero-cost, privacy-safe counter.
Takes about 10 minutes to set up.

---

## What you get

A tiny web server (called a Worker) that receives a ping every time:
- Someone installs the extension → `install`
- Someone uses X with the extension active → `active_session`
- A tweet gets hidden → `tweets_hidden` (batched count)
- Someone toggles the filter → `toggle_on` / `toggle_off`
- Someone adds a whitelist entry → `whitelist_add`

You see totals in your Cloudflare dashboard. Zero personal data stored.

---

## Step 1: Create a free Cloudflare account

Go to https://dash.cloudflare.com/sign-up — free, no credit card needed.

---

## Step 2: Create a KV Namespace (the database)

1. In the Cloudflare dashboard, go to: **Workers & Pages → KV**
2. Click **Create namespace**
3. Name it: `BTF_ANALYTICS`
4. Copy the **Namespace ID** — you'll need it in step 4.

---

## Step 3: Create the Worker

1. Go to **Workers & Pages → Create application → Create Worker**
2. Name it: `bluetick-analytics`
3. Click **Deploy** (ignore the default code for now)
4. Click **Edit code** and paste the code below:

```javascript
// ============================================================
// Cloudflare Worker — BlueTick Filter Analytics
// Receives anonymous pings, increments counters in KV.
// No personal data stored. No IP logged.
// ============================================================

export default {
  async fetch(request, env) {
    // Allow CORS so the extension can reach this endpoint
    const corsHeaders = {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET, OPTIONS",
    };

    if (request.method === "OPTIONS") {
      return new Response(null, { headers: corsHeaders });
    }

    const url = new URL(request.url);
    const event   = url.searchParams.get("e") || "unknown";
    const count   = parseInt(url.searchParams.get("n") || "1", 10);
    const version = url.searchParams.get("v") || "unknown";

    // Whitelist allowed event names to prevent abuse
    const allowed = new Set([
      "install", "update", "active_session",
      "tweets_hidden", "toggle_on", "toggle_off",
      "whitelist_add",
    ]);

    if (!allowed.has(event)) {
      return new Response("bad event", { status: 400, headers: corsHeaders });
    }

    // Increment the counter in KV
    // Key format: "event:YYYY-MM"  (monthly buckets so you can see trends)
    const month = new Date().toISOString().slice(0, 7); // "2025-04"
    const key   = `${event}:${month}`;

    const current = parseInt(await env.BTF_ANALYTICS.get(key) || "0", 10);
    await env.BTF_ANALYTICS.put(key, String(current + count));

    // Also increment the all-time total
    const totalKey = `${event}:total`;
    const total    = parseInt(await env.BTF_ANALYTICS.get(totalKey) || "0", 10);
    await env.BTF_ANALYTICS.put(totalKey, String(total + count));

    return new Response("ok", { status: 200, headers: corsHeaders });
  },
};
```

5. Click **Save and deploy**

---

## Step 4: Bind KV to the Worker

1. Go to your Worker → **Settings → Bindings**
2. Click **Add binding → KV namespace**
3. Variable name: `BTF_ANALYTICS`
4. KV namespace: select `BTF_ANALYTICS` (the one you created in step 2)
5. Save

---

## Step 5: Get your Worker URL

Your Worker URL looks like:
`https://bluetick-analytics.YOUR_SUBDOMAIN.workers.dev`

Test it by visiting:
`https://bluetick-analytics.YOUR_SUBDOMAIN.workers.dev/ping?e=install&v=test`

You should see: `ok`

---

## Step 6: Update the extension code

In these 3 files, replace:
```
https://YOUR_WORKER.YOUR_SUBDOMAIN.workers.dev/ping
```
with your actual Worker URL:
- `content.js` (line 10)
- `background.js` (line 8)
- `popup.js` (line 68)

---

## Viewing your analytics

In Cloudflare dashboard → Workers & Pages → KV → BTF_ANALYTICS → View

You'll see entries like:
```
install:total          → 4821
active_session:2025-04 → 12304
tweets_hidden:total    → 891024
```

---

## Free tier limits

Cloudflare's free Workers plan includes:
- 100,000 requests/day  (plenty for early growth)
- 1 GB KV storage
- No credit card required

At 100k users generating ~5 pings/day = 500k req/day.
At that point, upgrade to the $5/month Workers Paid plan.
