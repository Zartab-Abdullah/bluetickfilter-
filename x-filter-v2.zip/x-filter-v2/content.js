// ============================================================
// content.js — BlueTick Filter for X  v1.1
// Runs directly on x.com / twitter.com.
// Hides tweets from paid-verified accounts unless whitelisted.
// ============================================================

// ── ANALYTICS (inline copy so content scripts can use it) ──
const ANALYTICS_ENDPOINT = "https://YOUR_WORKER.YOUR_SUBDOMAIN.workers.dev/ping";
const EXT_VERSION = "1.1.0";

async function ping(event, count = 1) {
  try {
    const { analyticsEnabled } = await chrome.storage.sync.get({ analyticsEnabled: true });
    if (!analyticsEnabled) return;
  } catch (_) { return; }
  const url = `${ANALYTICS_ENDPOINT}?e=${encodeURIComponent(event)}&n=${count}&v=${EXT_VERSION}`;
  fetch(url, { method: "GET", keepalive: true }).catch(() => {});
}

// ── STATE ────────────────────────────────────────────────────
let whitelist      = new Set();
let filterEnabled  = true;
let sessionHidden  = 0;   // count of tweets hidden this page visit
let pendingPing    = 0;   // batch analytics: accumulate before sending

// ── BATCH ANALYTICS FLUSH (every 30 s) ───────────────────────
// Instead of pinging for every single tweet, we accumulate counts
// and flush them in one request — saves network, looks less suspicious.
setInterval(() => {
  if (pendingPing > 0) {
    ping("tweets_hidden", pendingPing);
    pendingPing = 0;
  }
}, 30_000);

// Also flush when the tab is being unloaded
window.addEventListener("pagehide", () => {
  if (pendingPing > 0) {
    ping("tweets_hidden", pendingPing);
    pendingPing = 0;
  }
});

// ── LOAD SETTINGS ────────────────────────────────────────────
function loadSettings(callback) {
  chrome.storage.sync.get(
    { whitelist: [], filterEnabled: true },
    (data) => {
      whitelist = new Set(
        data.whitelist.map((u) => u.toLowerCase().replace(/^@/, ""))
      );
      filterEnabled = data.filterEnabled;
      if (callback) callback();
    }
  );
}

// Live settings sync (popup changes apply instantly)
chrome.storage.onChanged.addListener((changes) => {
  if (changes.whitelist) {
    whitelist = new Set(
      changes.whitelist.newValue.map((u) => u.toLowerCase().replace(/^@/, ""))
    );
  }
  if (changes.filterEnabled !== undefined) {
    filterEnabled = changes.filterEnabled.newValue;
  }
  scanAll();
});

// ── BLUE-TICK DETECTION ───────────────────────────────────────
// X uses several possible DOM structures — we check all of them.
// If X changes their markup in the future, add new selectors here.
const TICK_SELECTORS = [
  '[data-testid="icon-verified"]',
  'svg[aria-label="Verified account"]',
  '[aria-label="Verified account"]',
  // Fallback: any SVG whose path closely matches the checkmark badge
  'svg[data-testid*="verif"]',
];

function hasBlueTick(tweetEl) {
  return TICK_SELECTORS.some((sel) => tweetEl.querySelector(sel));
}

// ── USERNAME EXTRACTION ───────────────────────────────────────
const SKIP_PATHS = new Set([
  "home","explore","notifications","messages","search",
  "settings","i","compose","login","signup","intent",
]);

function getUsername(tweetEl) {
  const links = tweetEl.querySelectorAll('a[href^="/"]');
  for (const link of links) {
    const href = link.getAttribute("href") || "";
    const match = href.match(/^\/([A-Za-z0-9_]{1,50})(?:\/|$)/);
    if (match) {
      const candidate = match[1].toLowerCase();
      if (!SKIP_PATHS.has(candidate)) return candidate;
    }
  }
  return null;
}

// ── HIDE/SHOW LOGIC ───────────────────────────────────────────
function shouldHide(tweetEl) {
  if (!filterEnabled) return false;
  if (!hasBlueTick(tweetEl)) return false;
  const user = getUsername(tweetEl);
  if (user && whitelist.has(user)) return false;
  return true;
}

function processTweet(tweetEl) {
  const hide = shouldHide(tweetEl);
  const wasHidden = tweetEl.classList.contains("btf-hidden");

  if (hide && !wasHidden) {
    tweetEl.classList.add("btf-hidden");
    tweetEl.classList.remove("btf-visible");
    sessionHidden++;
    pendingPing++;
    // Expose session count so popup can read it
    document.documentElement.dataset.btfHidden = sessionHidden;
  } else if (!hide && wasHidden) {
    tweetEl.classList.remove("btf-hidden");
    tweetEl.classList.add("btf-visible");
  }
}

// ── SCAN ALL ─────────────────────────────────────────────────
function scanAll() {
  document.querySelectorAll('article[data-testid="tweet"]').forEach(processTweet);
}

// ── MUTATION OBSERVER (infinite scroll) ──────────────────────
const observer = new MutationObserver((mutations) => {
  for (const mutation of mutations) {
    for (const node of mutation.addedNodes) {
      if (node.nodeType !== 1) continue;
      if (node.matches?.('article[data-testid="tweet"]')) {
        processTweet(node);
      }
      node.querySelectorAll?.('article[data-testid="tweet"]').forEach(processTweet);
    }
  }
});

observer.observe(document.body, { childList: true, subtree: true });

// ── INIT ─────────────────────────────────────────────────────
loadSettings(() => {
  scanAll();
  // Ping active session once per page load (batched, no personal data)
  ping("active_session");
});
