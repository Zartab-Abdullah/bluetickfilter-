// ============================================================
// background.js — Service Worker
// Handles install event, opens welcome page, fires install ping.
// ============================================================

const ANALYTICS_ENDPOINT = "https://YOUR_WORKER.YOUR_SUBDOMAIN.workers.dev/ping";
const EXT_VERSION = "1.1.0";

function ping(event) {
  const url = `${ANALYTICS_ENDPOINT}?e=${encodeURIComponent(event)}&v=${EXT_VERSION}`;
  fetch(url, { method: "GET", keepalive: true }).catch(() => {});
}

chrome.runtime.onInstalled.addListener((details) => {
  if (details.reason === "install") {
    // Set defaults
    chrome.storage.sync.set({
      whitelist:        [],
      filterEnabled:    true,
      analyticsEnabled: true,  // user can opt out in popup settings
      hasSeenWelcome:   true,
      installDate:      Date.now(),
      totalHidden:      0,
    });

    // Open welcome/monetization page
    chrome.tabs.create({ url: "welcome.html" });

    // Anonymous install ping
    ping("install");
  }

  if (details.reason === "update") {
    ping("update");
  }
});
