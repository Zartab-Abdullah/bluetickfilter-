// ============================================================
// popup.js — BlueTick Filter  v1.1
// ============================================================

const masterToggle    = document.getElementById("masterToggle");
const masterLbl       = document.getElementById("masterLbl");
const analyticsToggle = document.getElementById("analyticsToggle");
const usernameInput   = document.getElementById("usernameInput");
const addBtn          = document.getElementById("addBtn");
const chipList        = document.getElementById("chipList");
const whitelistCount  = document.getElementById("whitelistCount");
const hiddenCount     = document.getElementById("hiddenCount");
const totalCount      = document.getElementById("totalCount");
const toast           = document.getElementById("toast");

let whitelist = [];

// ── TOAST ────────────────────────────────────────────────────
function showToast(msg, isErr = false) {
  toast.textContent = msg;
  toast.classList.toggle("err", isErr);
  toast.classList.add("show");
  setTimeout(() => toast.classList.remove("show"), 1800);
}

// ── RENDER CHIPS ─────────────────────────────────────────────
function renderChips() {
  chipList.innerHTML = "";
  whitelistCount.textContent = whitelist.length;

  if (!whitelist.length) {
    chipList.innerHTML = '<span class="empty">No exceptions yet — all blue-tick tweets are hidden.</span>';
    return;
  }

  whitelist.forEach((u) => {
    const chip = document.createElement("div");
    chip.className = "chip";
    chip.innerHTML = `<span class="chip-at">@</span>${u}<button class="chip-rm" data-u="${u}">✕</button>`;
    chipList.appendChild(chip);
  });

  chipList.querySelectorAll(".chip-rm").forEach((btn) =>
    btn.addEventListener("click", () => removeUser(btn.dataset.u))
  );
}

// ── ADD USER ─────────────────────────────────────────────────
function addUser() {
  const raw = usernameInput.value.trim().replace(/^@/, "").toLowerCase();
  if (!raw) return;
  if (!/^[a-z0-9_]{1,50}$/.test(raw)) {
    showToast("❌ Invalid username", true); return;
  }
  if (whitelist.includes(raw)) {
    showToast("Already in whitelist"); usernameInput.value = ""; return;
  }
  whitelist.push(raw);
  chrome.storage.sync.set({ whitelist });
  usernameInput.value = "";
  renderChips();
  showToast(`✓ @${raw} added`);

  // Analytics ping for whitelist feature usage
  pingFeature("whitelist_add");
}

function removeUser(u) {
  whitelist = whitelist.filter((x) => x !== u);
  chrome.storage.sync.set({ whitelist });
  renderChips();
  showToast(`Removed @${u}`);
}

// ── MASTER TOGGLE ─────────────────────────────────────────────
masterToggle.addEventListener("change", () => {
  const on = masterToggle.checked;
  masterLbl.textContent = on ? "ON" : "OFF";
  masterLbl.classList.toggle("on", on);
  chrome.storage.sync.set({ filterEnabled: on });
  showToast(on ? "Filter ON" : "Filter OFF");
  pingFeature("toggle_" + (on ? "on" : "off"));
});

// ── ANALYTICS TOGGLE ─────────────────────────────────────────
analyticsToggle.addEventListener("change", () => {
  chrome.storage.sync.set({ analyticsEnabled: analyticsToggle.checked });
  showToast(analyticsToggle.checked ? "Stats enabled" : "Stats disabled");
});

// ── ANONYMOUS FEATURE PING ───────────────────────────────────
function pingFeature(event) {
  chrome.storage.sync.get({ analyticsEnabled: true }, (d) => {
    if (!d.analyticsEnabled) return;
    const url = `https://YOUR_WORKER.YOUR_SUBDOMAIN.workers.dev/ping?e=${event}&v=1.1.0`;
    fetch(url, { method: "GET" }).catch(() => {});
  });
}

// ── LIVE HIDDEN COUNT (reads from active tab's DOM) ──────────
function refreshLiveCount() {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (!tabs[0]?.id) return;
    chrome.scripting.executeScript(
      {
        target: { tabId: tabs[0].id },
        func: () => ({
          hidden: document.querySelectorAll('article[data-testid="tweet"].btf-hidden').length,
          // Read the session total we stored on the <html> element
          session: parseInt(document.documentElement.dataset.btfHidden || "0", 10),
        }),
      },
      (results) => {
        if (results?.[0]?.result) {
          hiddenCount.textContent = results[0].result.hidden;
        }
      }
    );
  });
}

// ── LOAD EVERYTHING ON OPEN ───────────────────────────────────
chrome.storage.sync.get(
  {
    whitelist: [], filterEnabled: true,
    analyticsEnabled: true, totalHidden: 0,
  },
  (data) => {
    whitelist              = data.whitelist;
    masterToggle.checked   = data.filterEnabled;
    analyticsToggle.checked = data.analyticsEnabled;
    masterLbl.textContent  = data.filterEnabled ? "ON" : "OFF";
    masterLbl.classList.toggle("on", data.filterEnabled);
    totalCount.textContent = data.totalHidden > 999
      ? (data.totalHidden / 1000).toFixed(1) + "k"
      : data.totalHidden;
    renderChips();
    refreshLiveCount();
  }
);

// ── EVENTS ───────────────────────────────────────────────────
addBtn.addEventListener("click", addUser);
usernameInput.addEventListener("keydown", (e) => { if (e.key === "Enter") addUser(); });
