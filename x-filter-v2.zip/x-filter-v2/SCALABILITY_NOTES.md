# Scalability & Future Sale Notes

## Why this architecture scales to 100k+ users

### Zero server costs at any user count
Every filter runs 100% in the browser. No matter if you have 10 users or 10 million,
your server bill is $0. The only external call is the optional analytics ping (< 1KB).

### chrome.storage.sync
- Syncs whitelist across all the user's devices automatically
- Costs you nothing — Google/Microsoft host it
- Works offline (reads from local cache)
- Scales to any number of users

### Cloudflare Worker analytics
- Free up to 100k requests/day
- At 100k users × 5 pings/day = 500k/day → upgrade to $5/month Workers Paid
- All data is yours, in your Cloudflare account

---

## Preparing to sell the extension

If you grow to 50k+ users, the extension has real sale value.
Buyers will look at:

### 1. Clean ownership proof
- Keep the extension registered under a business email, not personal
- Use a domain you own (e.g. bluetickfilter.com) for the welcome page
- Store the source code in a private GitHub repo

### 2. Analytics you control
- The Cloudflare KV data proves your user numbers
- Export monthly CSVs from KV before any sale discussions
- Record install count from Edge/Chrome dashboards as screenshots monthly

### 3. Monetization already working
- If you have $X/month coffee donations → document it
- Ad revenue from EthicalAds → shows the business model
- Buyers pay 2-4× annual revenue for browser extensions

### 4. Clean, readable code
- The code in this repo is well-commented — any developer can maintain it
- Keep the architecture simple: no frameworks, no build steps needed
- Document the analytics endpoint in CLOUDFLARE_WORKER.md (done)

---

## Future features that increase value

Roughly in order of impact:

1. **"Show tweet" button** — instead of hard-hiding, show a blurred
   placeholder with a "Show anyway" button. Adds 5 lines of CSS, feels premium.

2. **Filter by keyword** — hide any tweet containing specific words.
   Already have the DOM access; just extend `shouldHide()` in content.js.

3. **Stats page** — a full-page dashboard (extension page) showing
   historical hidden counts, top filtered accounts, etc.

4. **Batch import whitelist** — paste multiple @usernames at once.

5. **Firefox port** — same codebase, different store listing.
   Doubles your potential user base with ~2 hours of work.

6. **Chrome Web Store listing** — same extension, second distribution channel.

---

## Code change log (for buyers / future developers)

v1.0.0 — Initial release
  - Core filtering engine
  - Whitelist via popup
  - Welcome page with donation CTA

v1.1.0 — Current
  - Anonymous Cloudflare analytics
  - User opt-out toggle in popup
  - All-time hidden counter
  - Batched analytics pings (perf improvement)
  - Horizontal welcome page layout
