// ============================================================
// analytics.js  — BlueTick Filter  (shared by content + background)
//
// PRIVACY CONTRACT (safe for all store policies):
//  • No IP stored (Cloudflare Worker discards it)
//  • No user ID, no fingerprint, no browsing history
//  • Only anonymous aggregate counters:
//      install | active_session | tweets_hidden | feature_toggle
//  • Can be disabled by user (stored in chrome.storage.sync)
//
// HOW IT WORKS:
//  We fire a tiny GET request to a free Cloudflare Worker URL.
//  The Worker just increments a counter in Cloudflare KV storage.
//  You see totals in the Cloudflare dashboard — nothing else.
//
// SETUP (one-time, free):
//  1. Go to https://dash.cloudflare.com → Workers & Pages → Create
//  2. Paste the worker code from CLOUDFLARE_WORKER.md
//  3. Replace ANALYTICS_ENDPOINT below with your worker URL
// ============================================================

// ── REPLACE THIS with your Cloudflare Worker URL after setup ──
const ANALYTICS_ENDPOINT = "https://YOUR_WORKER.YOUR_SUBDOMAIN.workers.dev/ping";

// Extension version — bump this in manifest.json and here together
const EXT_VERSION = "1.1.0";

/**
 * Fire an anonymous analytics ping.
 * @param {string} event  - e.g. "install" | "active_session" | "tweets_hidden" | "whitelist_add"
 * @param {number} [count=1] - for count-type events like tweets_hidden
 */
async function ping(event, count = 1) {
  // Respect user opt-out
  try {
    const { analyticsEnabled } = await chrome.storage.sync.get({ analyticsEnabled: true });
    if (!analyticsEnabled) return;
  } catch (_) {
    return; // storage unavailable — skip silently
  }

  // No await — fire and forget so we never slow anything down
  const url = `${ANALYTICS_ENDPOINT}?e=${encodeURIComponent(event)}&n=${count}&v=${EXT_VERSION}`;
  fetch(url, { method: "GET", keepalive: true }).catch(() => {
    // Network errors are silently ignored — analytics must never break the extension
  });
}
